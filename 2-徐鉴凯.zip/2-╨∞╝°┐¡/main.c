#include "init.h"
#include "parse.h"
#include "def.h"

char cmdline[MAXLINE+1];
char avline[MAXLINE+1];
COMMAND cmd;

int main(void)
{
	printf("Our cmd:\nls:\t--l\t--a\t--h\t--d\necho\ncat:\t--h\npwd\nclear\ndate:\t--h\t--d\nwho\nmkdir:\t--h\ncp\nmv\nrm\nwc:\t--l\t--w\t--m\t--c\t--L\n");
	//初始操作
	signal_control();
	//shell循环
	shell_loop();
	return 0;
}
