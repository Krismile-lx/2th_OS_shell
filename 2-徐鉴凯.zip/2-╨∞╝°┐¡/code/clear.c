#include <stdio.h>
#include <unistd.h>

int main(){
    fputs("\x1b[2J\x1b[H", stdout); //VT100的控制码,\x1b[2 清除整个屏幕，行属性变成单宽单高，光标位置不变;\x1b[H 光标移动到行首
    return 0;
}
