    #include<stdio.h>
    #include<unistd.h>
    #include<sys/stat.h>
    #include<string.h>
    #include<stdlib.h>
    

char * getFileName(char * fileName){
    	char tp[100],*nm=(char*)malloc(sizeof(char));
    	int i,j=0;
    	for(i=strlen(fileName)-1;i>=0;i--)
    	{
    		if(fileName[i]=='/')break;//strlen所作的是一个计数器的工作，它从内存的某个位置（可以是字符串开头，中间某个位置，甚至是某个不确定的内存区域）开始扫描，直到碰到第一个字符串结束符'\0'为止，然后返回计数器值(长度不包含'\0')
    	}
    	for(i++;i<strlen(fileName);i++)
    	{
    		tp[j++]=fileName[i];
    	}
    	tp[j]='\0';
    	strcpy(nm,tp);//字符串复制
    	
    	return nm;
    }
    int main(int ac,char * av[]){
    	struct stat st;//获取文件信息
    	if(ac!=3){
    		fprintf(stderr,"usage: %s source destination not found\n",*av);
    	}
    	
    	if(stat(av[1],&st)==-1 || S_ISDIR(st.st_mode)){
    		printf("source is not a file");
    		exit(1);
    	}
    	if(stat(av[2],&st)!=-1){//查看是不是目录 
    		if(S_ISDIR(st.st_mode)){
    			strcpy(av[2]+strlen(av[2]),"/");
    			strcpy(av[2]+strlen(av[2]),getFileName(av[1]));
    			strcpy(av[2]+strlen(av[2]),"\0");
    		}else{
    			printf("destination file is already exist\n");
    			//exit(1);  不可以退出，真正的linux也不会出现提示。
    		}
    	}
    	/*
    	光下面一个函数就可以实现  复制包含目录的文件，但是如果 第二个参数是目录的话会失败的，所以要处理 .
    用link如果目标目录文件存在就会失败，不许创建而linux中mv与cp都是可以覆盖目标文件的。
    	*/
    	if(rename(av[1],av[2])==-1){
    		printf("error!\n");
    	}
 
    	return 1;
    }
