#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int beg = 1;
    
    while(beg < argc){
        fprintf(stdout, argv[beg++]);
        if(argc != beg)     /*  �����м�Ŵ�ӡ�ո�  */
            fprintf(stdout, " ");
        }

    fprintf(stdout, "\n");

    exit(0);
}

