#ifndef _INIT_H_
#define _INIT_H_

void signal_control(void);
void init(void);

#endif /* _INIT_H_ */
