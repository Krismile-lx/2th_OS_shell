#ifndef _DEF_H_
#define _DEF_H_
#include <stdio.h>
#include <stdlib.h>

#define MAXLINE 1024		//命令行最长长度	
#define MAXARG 20		//命令最多的参数个数
#define PIPELINE 5		//命令最多支持的管道个数

typedef struct command
{
	char *args[MAXARG+1];	//命令的参数列表，多个NULL结束
} COMMAND;


#endif /* _DEF_H_ */
